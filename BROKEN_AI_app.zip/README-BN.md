# BROKEN AI
1. Upload this project to GitHub.
2. Import the repo into Vercel.
3. Add Environment Variable: OPENAI_API_KEY (never put it in public JS).
4. Deploy.
5. Open the deployed URL on Android Chrome and choose ⋮ → Add to Home screen / Install app.
6. The app accepts any natural-language request; no fixed command list is required.
